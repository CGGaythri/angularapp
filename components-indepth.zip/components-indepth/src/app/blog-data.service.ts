import { Injectable } from '@angular/core';
import { BlogPost } from 'src/app/shared/blog-post';

@Injectable({
  providedIn: 'root'
})
export class BlogDataService {

  constructor() { }

  getData(): BlogPost[][]{
    return [
      [
        {
          title: "Blog Post 1",
          summary: "Summary 1 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 2",
          summary: "Summary 2 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 3",
          summary: "Summary 3 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 4",
          summary: "Summary 4 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 5",
          summary: "Summary 5 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        }
      ],
      [
        {
          title: "Blog Post 6",
          summary: "Summary 6 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 7",
          summary: "Summary 7 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 8",
          summary: "Summary 8 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 9",
          summary: "Summary 9 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 10",
          summary: "Summary 10 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        }
      ],
      [
        {
          title: "Blog Post 11",
          summary: "Summary 11 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 12",
          summary: "Summary 12 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 13",
          summary: "Summary 13 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 14",
          summary: "Summary 14 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        },
        {
          title: "Blog Post 15",
          summary: "Summary 15 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."
        }
      ]
    ]
  }

}
