import { Component, OnInit, ViewChildren, QueryList } from '@angular/core';
import { BlogPost } from 'src/app/shared/blog-post';
import { BlogPostTileComponent } from 'src/app/blog-post-tile/blog-post-tile.component';
import { BlogDataService } from 'src/app/blog-data.service';

@Component({
  selector: 'app-blog-list',
  templateUrl: './blog-list.component.html',
  styleUrls: ['./blog-list.component.scss']
})
export class BlogListComponent implements OnInit {

  blogPosts: BlogPost[][]=[];
  currentPage: number;
  @ViewChildren('tile') blogPostTitleComponents: QueryList<BlogPostTileComponent>;

  constructor(private blogDataService: BlogDataService) { }

  ngOnInit() {
    this.currentPage = 0;
    this.blogPosts = this.blogDataService.getData();
    
    // this.blogPosts.push(new BlogPost("Blog Post 1","Summary 1 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."));
    // this.blogPosts.push(new BlogPost("Blog Post 2","Summary 2 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."));
    // this.blogPosts.push(new BlogPost("Blog Post 3","Summary 3 Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean lobortis consequat semper. Vestibulum dignissim nisl purus, ac faucibus ex elementum in. Quisque commodo ante sem, eget mollis nisi commodo cursus. Proin a felis id nibh varius ultricies in at nisi. Proin porttitor magna libero, in venenatis purus molestie bibendum. Nam fringilla, enim tristique varius suscipit, nunc eros laoreet libero, ut commodo tortor mauris vitae ante. Fusce pellentesque, turpis id feugiat porttitor, augue augue volutpat lectus, efficitur finibus erat arcu pulvinar tortor. Phasellus non elit nulla. Curabitur vitae massa sit amet ipsum aliquet luctus luctus maximus enim. Pellentesque sed tristique eros. Fusce et auctor erat, ut fringilla metus. Vestibulum euismod, erat non tempor consequat, ante libero aliquet arcu, nec fermentum diam est interdum velit. Ut non fringilla justo. Praesent condimentum velit ac turpis eleifend pellentesque."));
  }

  updatePage(newPage){
    console.log("Event emitted and method executed");
    this.currentPage = newPage;
  }

  expandAll(){
    this.blogPostTitleComponents
      .forEach(element => {
        element.showFullSummary();
      });
  }

  favoriteAll(){
    //change detection
    this.blogPosts[this.currentPage] = this.blogPosts[this.currentPage]
      .map(element => ({
        title: element.title,
        summary: element.summary,
        isFav: true
    }));
    // this.blogPosts[this.currentPage]
    //   .forEach(element => {
    //     element.isFav=true;
    //   });
  }
}
