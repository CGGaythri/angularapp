import { Component, OnInit } from '@angular/core';
import { Employee } from '../models/employee.model';
import * as _ from 'lodash'; 
import { transformAll } from '@angular/compiler/src/render3/r3_ast';
import { FormPoster } from '../services/form.poster.service';
import { NgForm } from '@angular/forms/src/directives/ng_form';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
 languages = []
 employeeModel = new Employee("John","Jack", true, "w2", "default", "")
 hasPrimaryLanguageError=false;

  constructor(private formPoster: FormPoster) {
    this.formPoster.getLanguages()
      .subscribe(
        data => this.languages = data.language,
        err => console.log('get error:', err)
      )
   }

  ngOnInit() {
  }

  lastNameToUpperCase(value: string)
  {  
    this.employeeModel.lastName = _.upperCase(value);
  } 
  
  validatePrimaryLanguage(value)
  {
    if (value === 'default')
      this.hasPrimaryLanguageError = true;
    else 
      this.hasPrimaryLanguageError = false;
  }

  submitForm(form: NgForm){
    //validate from

    this.validatePrimaryLanguage(this.employeeModel.primaryLanguage);

    if(this.hasPrimaryLanguageError)
      return;

    //console.log(this.employeeModel);
    this.formPoster.postEmployeeForm(this.employeeModel)
      .subscribe(
        data => console.log('success: ', data),
        err => console.log('failure: ', err)

      )
  }
 
}