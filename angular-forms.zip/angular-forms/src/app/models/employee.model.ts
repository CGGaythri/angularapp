import { BrowserDynamicTestingModule } from "@angular/platform-browser-dynamic/testing";


export class Employee{
    constructor(
        public firstName: string, 
        public lastName: string,
        public isFullTime: boolean,
        public paymentType: string,
        public primaryLanguage:string,
        public hireDate:string
    )
    {

    }
}