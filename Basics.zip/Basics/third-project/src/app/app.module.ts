import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'

import { AppComponent } from './app.component';
import { ViewModule } from 'src/app/view/view.module';
import { TestService } from 'src/app/test.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule, ViewModule, HttpClientModule
  ],
  providers: [TestService],
  bootstrap: [AppComponent]
})
export class AppModule { }
