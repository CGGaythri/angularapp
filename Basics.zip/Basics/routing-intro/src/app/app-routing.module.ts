import { NgModule } from '@angular/core';
import { Route, RouterModule } from '@angular/router';
import { HomeComponent } from 'src/app/home/home.component';
import { SettingsComponent } from 'src/app/settings/settings.component';
import { PageNotFoundComponent } from 'src/app/page-not-found/page-not-found.component';
import { SettingsProfileComponent } from 'src/app/settings-profile/settings-profile.component';
import { SettingsContactComponent } from 'src/app/settings-contact/settings-contact.component';

const routes: Route[] = [
  {path:'', redirectTo:'/home', pathMatch:'full'},
  {path: 'home', component: HomeComponent},
  {path: 'settings', component: SettingsComponent, 
    children: [
      {path:'', redirectTo:'profile', pathMatch:'full'},
      {path: 'profile', component:SettingsProfileComponent},
      {path: 'contact', component:SettingsContactComponent}
    ]},
  {path:'**', component:PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
