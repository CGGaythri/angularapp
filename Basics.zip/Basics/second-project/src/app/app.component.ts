import { Component } from '@angular/core';
import { User } from './address-card/user.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  user: User;
  inputText : string ="Sample Text";

  constructor(){
    this.user = new User();
    this.user.name="Foo Bar";
    this.user.designation="Software Developer";
    this.user.address="123 Main St, City, State, 10000";
    this.user.phone=['123-123-1234', '345-345-3454', '466-457-4654', '678-677-5677'];
  }

}
