import { Component, OnInit } from '@angular/core';
import { Input } from '@angular/core';
import { User } from './user.model';

@Component({
  selector: 'app-address-card',
  templateUrl: './address-card.component.html',
  styleUrls: ['./address-card.component.css']
})
export class AddressCardComponent implements OnInit {

  // user: any;  
  @Input('user') user :User;

  isCollapsed: boolean = true;

  constructor() {
    
   }

  ngOnInit() {
    // this.user = {
    //   name: this.userObj.name, //"Foo Bar",
    //   title: this.userObj.designation, //"Software Developer", 
    //   address: this.userObj.address, //"123 Main St, City, State, 10000",
    //   phone: this.userObj.phone //['123-123-1234', '345-345-3454', '466-457-4654']
    //   };
  }

  toggleCollape() {
  this.isCollapsed =! this.isCollapsed;
}
}
