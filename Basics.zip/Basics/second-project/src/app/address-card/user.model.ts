export class User{
    name: string;
    designation: string;
    address: string;
    phone: string[];
}