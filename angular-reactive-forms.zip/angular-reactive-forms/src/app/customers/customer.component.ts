import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl,ValidatorFn, FormArray } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';

import { Customer } from './customer';


function emailMatcher(c:AbstractControl){
  let emailControl = c.get('email');
  let confirmEmailControl = c.get('confirmEmail');

  if (emailControl.pristine || confirmEmailControl.pristine) {
    return null;
  }

  if (emailControl.value === confirmEmailControl.value) {
    return null;
  }
  return {'match':true}
}

function ratingRange(min: number, max:number): ValidatorFn {
  return (c: AbstractControl):{[key: string]: boolean} | null => {
  if (c.value !== null && (isNaN(c.value) || c.value < min || c.value > max)){
    return{'range': true};
  }
  return null;
};
}


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customerForm: FormGroup;
  customer = new Customer();
  emailMessage:string;
  
  //property getter
  get addresses(): FormArray{
    return <FormArray>this.customerForm.get('addresses')
  }

  private validationMessages = {
    required: 'Please enter your email address.',
    pattern: 'Please enter a valid email address.'
  }

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    //Define FormModel for customer form
    //With Form builder
    this.customerForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(3)]],
      lastName:['', [Validators.required, Validators.maxLength(50)]], //{value:'n/a', disabled:true},
      emailGroup: this.fb.group({
        email:['',[Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+')]],
        confirmEmail: ['', Validators.required]
      }, {validator: emailMatcher}),
      phone:[''],
      notification:['email'],
      rating:['', ratingRange(1,5)],
      sendCatalog:true,
      addresses: this.fb.array([this.buildAddress()])
      
    });

    //witout form builder
    // this.customerForm = new FormGroup({
    //   firstName: new FormControl(),
    //   lastName: new FormControl(),
    //   email: new FormControl(),
    //   sendCatalog: new FormControl(true)
    // });

    //Watching
    this.customerForm.get('notification').valueChanges
                  .subscribe(value => this.setNotification(value));

    //Reacting: displaying validation messages
    const emailControl = this.customerForm.get('emailGroup.email');
    
    // emailControl.valueChanges.subscribe(value =>
    //   this.setMessages(emailControl));

    //Reactive Transformation
    emailControl.valueChanges.pipe(debounceTime(2000)).subscribe(value =>
      this.setMessages(emailControl));
  }

  addAddress():void {
    this.addresses.push(this.buildAddress());
  }

  buildAddress(): FormGroup {
    return this.fb.group({
      addressType:'home',
      street1:'',
      street2:'',
      city:'',
      state:'',
      zip:''
    })
  }

  save() {
    console.log(this.customerForm);
    console.log('Saved: ' + JSON.stringify(this.customerForm.value));
  }

  populateTestData(){
    // this.customerForm.setValue({
    //   firstName: 'Jack',
    //   lastName: 'Lewis',
    //   email: 'test123@test.com',
    //   sendCatalog:false
    // });

    this.customerForm.patchValue({
      firstName: 'Jack',
      lastName: 'Lewis',
      sendCatalog:false
    });
   
  }

  setNotification(notifyVia: string): void{
    const phoneControl = this.customerForm.get('phone');

    if (notifyVia === 'text'){
      phoneControl.setValidators(Validators.required);
    }
    else{
      phoneControl.clearValidators();
    }
    phoneControl.updateValueAndValidity();
  }

  setMessages(c: AbstractControl):void {
    this.emailMessage = '';
    if((c.touched || c.dirty) && c.errors){
      this.emailMessage = Object.keys(c.errors).map(key => 
        this.validationMessages[key]).join(' ');
    }
  }
}
